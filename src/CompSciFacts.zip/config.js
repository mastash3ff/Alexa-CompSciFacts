'use strict';

var config = {};

config.appId = "amzn1.echo-sdk-ams.app.d66d4b0b-8ab2-488f-8287-81dd444de254";

module.exports = config;
